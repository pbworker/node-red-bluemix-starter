# node-red-contrib-nodes-memory
A node-red node to analyse the memory consumption of the nodes.
